# Fees-Management-System
Student Fees Management System is capable of managing each and every data regarding student, payments etc. Student Management System helps us in managing in an extremely efficient way. This Student Fees Management System works in an efficient manner.

## Technology used are :
Front End : Java, JavaSwing, JavaFX.
Back End : Database(Derby).
IDE used : Netbeans.

## Below are the screenshot of the application.
![Screenshot (83)](https://user-images.githubusercontent.com/58525668/82139883-f133ea00-9848-11ea-9e88-7e10b2b71dfa.png)

![Screenshot (84)](https://user-images.githubusercontent.com/58525668/82139914-43750b00-9849-11ea-8468-478be568e87a.png)

![Screenshot (85)](https://user-images.githubusercontent.com/58525668/82139921-5982cb80-9849-11ea-82ac-840965c3e05d.png)


